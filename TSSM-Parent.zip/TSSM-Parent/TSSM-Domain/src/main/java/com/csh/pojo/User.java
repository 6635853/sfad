package com.csh.pojo;

import lombok.*;

import java.time.LocalDateTime;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/1
 * @descript 用户实体类
 * @package com.bill.pojo
 */
@Setter
@Getter
@ToString
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {


    private int userId;
    private String userName;
    private String userPassword;
    private String userPhone;
    private String userEmail;
    private String userPlayerId;
    private int userSex;
    private int userRoleId;
    private LocalDateTime createdTime;

}
