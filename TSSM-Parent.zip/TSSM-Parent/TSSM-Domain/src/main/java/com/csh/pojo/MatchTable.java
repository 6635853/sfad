package com.csh.pojo;

import lombok.*;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 比赛表
 * @package com.csh.pojo
 */
@Setter
@Getter
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class MatchTable {
    private String matchNo;
    private int matchUserId;
    private String matchUserName;
    private int matchRefereeId;
    private String matchRefereeName;
    private String matchFlag;
    private String matchTime;
}
