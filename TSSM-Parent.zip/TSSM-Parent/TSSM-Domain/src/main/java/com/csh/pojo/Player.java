package com.csh.pojo;

import lombok.*;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/4
 * @descript 球员信息
 * @package com.csh.pojo
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Player {
    private String gameNo;
    private String gameName;
    private String playerAUserName;
    private String playerASumResult;
    private String playerBUserName;
    private String playerBSumResult;
    private String referee;
}
