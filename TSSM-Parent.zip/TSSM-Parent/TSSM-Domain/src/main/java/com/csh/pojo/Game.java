package com.csh.pojo;

import lombok.*;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 赛程实体类
 * @package com.csh.pojo
 */
@Setter
@Getter
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Game {
    private Integer gameId;
    private String gameName;
    private String gameAddress;
    private String gameTime;
    // 发布者
    private String gameAnnouncer;
    private String gameNo;
    private String gameFlag;
    // 赞助商
    private String gameSponsor;
    // 裁判
    private String gameRefereeName;
    private Integer gameRefereeId;


}
