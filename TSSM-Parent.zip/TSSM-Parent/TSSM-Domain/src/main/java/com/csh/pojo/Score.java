package com.csh.pojo;

import lombok.*;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 分数表
 * @package com.csh.pojo
 */
@Setter
@Getter
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Score{
    // 球员id
    private int scoreUserId;
    // 赛程编号
    private String scoreGameNo;
    // 分数
    private int scoreFraction;
    // 球员名称
    private String scoreUserName;
    // 裁判员id
    private int scoreRefereeId;
    // 裁判员名称
    private String scoreRefereeName;
    // 每一局的比赛结果
    private String scoreBureauResult;
}
