package com.csh.pojo;

import lombok.*;

import java.time.LocalDateTime;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/3
 * @descript cshi
 * @package com.csh.dao
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class TestUser {

    private int userId;
    private String userName;
    private String userPassword;
    private String userPhone;
    private String userEmail;
    private String userPlayerId;
    private int userSex;
    private int userRoleId;
    private LocalDateTime createdTime;

}
