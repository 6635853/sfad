package com.csh.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/3
 * @descript 异常控制
 * @package com.csh.controller
 */
@Controller
@RequestMapping(value = {"/error"})
public class ExceptionController {

    @RequestMapping(value = {"/error500"})
    public String error500() {
        return "err500";
    }

    @RequestMapping(value = {"/error404"})
    public String error404() {
        return "err404";
    }
}
