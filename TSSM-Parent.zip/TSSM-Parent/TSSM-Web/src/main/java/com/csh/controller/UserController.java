package com.csh.controller;

import com.csh.constant.game.GameConstant;
import com.csh.constant.match.MatchConstant;
import com.csh.constant.user.UserConstant;
import com.csh.pojo.Game;
import com.csh.pojo.MatchTable;
import com.csh.pojo.Score;
import com.csh.pojo.User;
import com.csh.service.GameService;
import com.csh.service.MatchTableService;
import com.csh.service.ScoreService;
import com.csh.service.UserService;
import com.csh.utils.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author Adminstrator
 * @version 1.0
 * @date 2020/6/1
 * @descript 用户控制类
 * @package com.bill.controller
 */
@Controller
@RequestMapping(value = "/user")
public class UserController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    private HttpSession httpSession;

    private final Lock lock = new ReentrantLock();

    @Autowired
    private UserService userService;

    @Autowired
    private MatchTableService matchTableService;

    @Autowired
    private ScoreService scoreService;

    @Autowired
    private GameService gameService;

    @RequestMapping(value = {"/userProfile/{userId}"})
    public String userProfile(@PathVariable("userId") int userId, HttpServletRequest request, HttpServletResponse response) {
        LOGGER.info(StringUtils.formatString(" @PathVariable Param Is ", userId));
        try {
            // 根据userId查询到用户
            httpSession = request.getSession();
            User user = userService.findUserByUserId(userId);
            if (!ObjectUtils.isEmpty(user)) {
                httpSession.setAttribute("userProfile", user);
                return "userProfile";
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "err500";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [userName, password, request, response]
     * @author Adminstrator
     * @createTime 2020/6/1 16:51
     * @description 用户登录
     */
    @RequestMapping(value = {"/login"}, method = RequestMethod.POST, produces = {"application/json"})
    public String userLogin(@RequestParam(value = "userName", required = false) String userName, @RequestParam(value = "userPassword", required = false) String userPassword, HttpServletRequest request, HttpServletResponse response) {
        Assert.notNull(userName, "userName can not be empty");
        Assert.notNull(userPassword, "userPassword can not be empty");
        String format = MessageFormat.format("User input information is {0} {1}", userName, userPassword);
        LOGGER.info(format);
        // 开始登录操作
        lock.lock();
        try {
//            String uPassword = MD5Utils.string2MD5(userPassword);
            httpSession = request.getSession();
            User user = userService.findUserByUserNameAndUserPassword(userName, userPassword);
            if (!ObjectUtils.isEmpty(user)) {
                httpSession.setAttribute("user", user);
                httpSession.setAttribute("successInfo", "登录成功");
                return "index";
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        } finally {
            lock.unlock();
        }

        return "err500";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [user, request, response]
     * @author Adminstrator
     * @createTime 2020/6/1 16:51
     * @description 用户注册
     * JSON.stringify($('form').serializeObject())
     */
    @RequestMapping(value = {"/registry"}, method = RequestMethod.POST, produces = {"application/json"})
    public String userRegistry(@RequestBody User user, HttpServletRequest request, HttpServletResponse response) {
        lock.lock();
        try {
            httpSession = request.getSession();
            if (!ObjectUtils.isEmpty(user)) {
//                user.setUserPassword(MD5Utils.string2MD5(user.getUserPassword()));
                user.setUserPlayerId(String.valueOf(System.currentTimeMillis()));
                user.setUserRoleId(UserConstant.USER_ROLE_PLAYER);
                user.setCreatedTime(LocalDateTime.now());
                int count = userService.insertUser(user);
                if (count > 0) {
                    httpSession.setAttribute("registryInfo", "注册成功，可登陆");
                    return "/";
                }
            }
            httpSession.setAttribute("registryInfo", "注册失败，请重试");
            response.sendRedirect("/registry");
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        } finally {
            lock.unlock();
        }
        return "err500";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [user, request, response]
     * @author Adminstrator
     * @createTime 2020/6/2 8:43
     * @description 修改个人信息
     */
    @RequestMapping(value = {"/update"})
    public String userUpdateInfoByUserId(@RequestBody User user, HttpServletRequest request, HttpServletResponse response) {
        lock.lock();
        try {
            httpSession = request.getSession();
            if (!ObjectUtils.isEmpty(user)) {
                int count = userService.updateUserByUser(user);
                if (count > 0) {
                    httpSession.setAttribute("successInfo", "信息修改成功");
                    return "index";
                }
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        } finally {
            lock.unlock();
        }
        return "err500";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [model, request, response]
     * @author Adminstrator
     * @createTime 2020/6/2 11:20
     * @description 展示所有比赛申请列表
     */
    @RequestMapping(value = {"/viewGameRequest"})
    public String viewAllGameRequest(Model model, HttpServletRequest request, HttpServletResponse response) {
        try {
            // 未开始的比赛
            List<Game> gameLists = gameService.findAll(GameConstant.GAME_FLAG_N);
            model.addAttribute("gameLists", gameLists);
            return "gameRequestList";
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "err500";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [gameId, request, response]
     * @author Administrator
     * @createTime 2020/6/5 17:41
     * @description 定时更新比赛的状态, 每个一个时间去检查
     */
    @RequestMapping(value = {"/updateRegularly"}, method = RequestMethod.GET)
    public String updateGameStatusRegularly(HttpServletRequest request, HttpServletResponse response) {
        lock.lock();
        try {
            LOGGER.info(" { " + System.currentTimeMillis() + " } ");
            httpSession = request.getSession();
            List<Game> gameList = gameService.findAll(MatchConstant.MATCH_FLAG_Y);
            gameList.stream().forEach(item -> {
                String gameTime = item.getGameTime();
                long time = new Date(gameTime).getTime();
                if ((time - System.currentTimeMillis()) < 1800000) {
                    String gameNo = item.getGameNo();
                    // 更新状态为进行中
                    try {
                        int count = matchTableService.updateMatchFlagByMatchNo(MatchConstant.MATCH_FLAG_ING, gameNo);
                    } catch (Exception e) {
                        LOGGER.error(e.getMessage(), e);
                    }
                }
            });
            httpSession.setAttribute("gameLists", matchTableService.findMatchByMatchFlag(MatchConstant.MATCH_FLAG_ING));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        } finally {
            lock.unlock();
        }
        return "err500";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [user, request, response]
     * @author Adminstrator
     * @createTime 2020/6/2 8:51
     * @description 申请比赛, 用户点击申请按钮是会把用户的个人信息传入后台
     */
    @RequestMapping(value = {"/submitGame/{gameNo}/{userId}"}, method = RequestMethod.GET, produces = {"application/json"})
    public String userSubmitGame(@PathVariable(value = "gameNo", required = false) String gameNo, @PathVariable(value = "userId", required = false) Integer userId, HttpServletRequest request, HttpServletResponse response) {
        Assert.notNull(userId, "userId can not be empty");
        Assert.notNull(gameNo, "gameNo can not be empty");
        httpSession = request.getSession();
        lock.lock();
        try {
            // 首先根据用户id和赛程no查询一下，如果已参加，则不能再次参赛
            MatchTable match = matchTableService.findMatchByUserIdAndMatchNo(userId, gameNo);
            if (!ObjectUtils.isEmpty(match)) {
                httpSession.setAttribute("matchInfo", "已成功参加过比赛，不能在此参加");
                return "gameRequestList";
            }
            // 查询用户
            User user = userService.findUserByUserId(userId);
            // 查询比赛
            Game game = gameService.findGameByGameNo(gameNo);
            // 创建一个MatchTable对象
            MatchTable matchTable = new MatchTable();
            matchTable.setMatchNo(gameNo);
            matchTable.setMatchUserId(user.getUserId());
            matchTable.setMatchUserName(user.getUserName());
            matchTable.setMatchRefereeId(game.getGameRefereeId());
            matchTable.setMatchRefereeName(game.getGameRefereeName());
            matchTable.setMatchFlag(MatchConstant.MATCH_FLAG_N);
            matchTable.setMatchTime(game.getGameTime());
            int count = matchTableService.insertMatchTable(matchTable);
            if (count > 0) {
                httpSession.setAttribute("matchInfo", "比赛申请成功，请按时参加");
                return "gameRequestList";
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        } finally {
            lock.unlock();
        }
        return "err500";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [userId, request, response]
     * @author Adminstrator
     * @createTime 2020/6/2 10:08
     * @description 查看球员单场比赛成绩
     */
    @RequestMapping(value = {"/searchGameResult/{userId}"}, method = RequestMethod.GET, produces = {"application/json"})
    public String viewUserSingleGameScoreByUserIdAndGameNo(@PathVariable(value = "userId") Integer userId, @RequestParam(value = "gameNo", required = false) String gameNo, HttpServletRequest request, HttpServletResponse response) {
        try {
            httpSession = request.getSession();
            if (org.springframework.util.StringUtils.isEmpty(gameNo)) {
                // 查询所有
                List<Score> scoreLists = scoreService.findAllScoreByUserId(userId);
                httpSession.setAttribute("scoreLists", scoreLists);
                return "gameResultSearch";
            }
            Score score = scoreService.findScoreByUserIdAndGameNo(userId, gameNo);
            httpSession.setAttribute("scoreLists", null);
            httpSession.setAttribute("singleScore", score);
            return "gameResultSearch";
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "err500";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [userId, request, response]
     * @author Adminstrator
     * @createTime 2020/6/2 10:23
     * @description 查看球员所有的比赛分数
     */
    @RequestMapping(value = {"/allGame"})
    public String viewUserAllGameScoreByUserId(@RequestParam("userId") int userId, HttpServletRequest request, HttpServletResponse response, Model model) {
        Assert.notNull(userId, "userId can not be empty");
        try {
            List<Score> scoreList = scoreService.findAllScoreByUserId(userId);
            model.addAttribute("allScore", scoreList);
            return "scoreList";
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "error";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [userId, request, response]
     * @author csh
     * @createTime 2020/6/5 10:12
     * @description 已参加比赛列表
     */
    @RequestMapping(value = {"/haveEntered/{userId}"}, method = RequestMethod.GET)
    public String viewUserHaveEntered(@PathVariable("userId") Integer userId, HttpServletRequest request, HttpServletResponse response) {
        try {
            httpSession = request.getSession();
            List<MatchTable> match = matchTableService.findMatchByUserIdAndMatchFlag(userId, MatchConstant.MATCH_FLAG_Y);
            httpSession.setAttribute("matchLists", match);
            return "haveEntered";
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "err500";
    }
}
