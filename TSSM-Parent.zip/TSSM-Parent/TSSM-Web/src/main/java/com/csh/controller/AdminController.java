package com.csh.controller;

import com.alibaba.fastjson.JSONObject;
import com.csh.constant.game.GameConstant;
import com.csh.constant.match.MatchConstant;
import com.csh.constant.user.UserConstant;
import com.csh.pojo.*;
import com.csh.service.GameService;
import com.csh.service.MatchTableService;
import com.csh.service.ScoreService;
import com.csh.service.UserService;
import com.csh.utils.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 管理员操作
 * @package com.csh.controller
 */
@Controller
@RequestMapping(value = {"/admin"})
public class AdminController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);

    private HttpSession httpSession;
    private final Lock lock = new ReentrantLock();

    @Autowired
    private GameService gameService;

    @Autowired
    private MatchTableService matchTableService;

    @Autowired
    private UserService userService;

    @Autowired
    private ScoreService scoreService;


    /**
     * @return java.lang.String
     * @throws
     * @params [game, request, response]
     * @author Administrator
     * @createTime 2020/6/2 10:31
     * @description 发起比赛通知
     */
    @RequestMapping(value = {"/makeRequest"}, method = RequestMethod.POST, produces = {"application/json;charset=utf8"})
    public String adminMakeGameRequest(@RequestBody Game game, HttpServletRequest request, HttpServletResponse response, Model model) {
        if (!ObjectUtils.isEmpty(game)) {
            httpSession = request.getSession();
            lock.lock();
            try {
                List<User> userList = userService.findUserByUserRoleId(UserConstant.USER_ROLE_REFEREE);
                // 此处采用最简单的随机方法
                int size = userList.size();
                Random random = new Random();
                int index = random.nextInt(size);
                User user = userList.get(index);
                game.setGameRefereeName(user.getUserName());
                game.setGameRefereeId(user.getUserId());
                game.setGameFlag(GameConstant.GAME_FLAG_N);
                httpSession.setAttribute("requestInfo", "申请已发出，等待球员申请");
                return "makeRequest";
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            } finally {
                lock.unlock();
            }
        }
        return "err500";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params []
     * @author Administrator
     * @createTime 2020/6/2 11:23
     * @description 查看所有参赛球员信息
     */
    @RequestMapping(value = {"/playerInfo"})
    public String adminViewAllPlayerInfo(HttpServletRequest request, HttpServletResponse response) {
        List<User> userLists = new ArrayList<>();
        httpSession = request.getSession();
        try {
            // 参赛球员的信息
            List<MatchTable> matchList = matchTableService.findMatchByMatchFlag(MatchConstant.MATCH_FLAG_Y);
            matchList.stream().forEach(item -> {
                try {
                    userLists.add(userService.findUserByUserId(item.getMatchUserId()));
                } catch (Exception e) {
                    LOGGER.error(e.getMessage(), e);
                }
            });
            httpSession.setAttribute("playerInfo", userLists);
            return "playerInfo";
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "error";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [request, response]
     * @author Administrator
     * @createTime 2020/6/4 10:49
     * @description 查看球员的请求列表
     */
    @RequestMapping(value = {"/requestList"}, method = RequestMethod.GET)
    public String requestlist(HttpServletRequest request, HttpServletResponse response) {
        try {
            httpSession = request.getSession();
            // 查询出来未参加比赛的人员信息
            List<MatchTable> matchLists = matchTableService.findMatchByMatchFlag(MatchConstant.MATCH_FLAG_N);
            httpSession.setAttribute("matchLists", matchLists);
            return "agreeRequest";
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "err500";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params []
     * @author Administrator
     * @createTime 2020/6/2 12:26
     * @description 同意球员所发起的参赛请求
     */
    @RequestMapping(value = {"/agreeRequest"}, method = RequestMethod.GET, produces = {"application/json"})
    public String adminAgreePlayerRequest(@RequestParam(value = "matchNo", required = false) String matchNo, @RequestParam(value = "userId", required = false) Integer userId, HttpServletRequest request, HttpServletResponse response) {
        Assert.notNull(userId, "userId can not be empty");
        Assert.notNull(matchNo, "matchNo can not be empty");
        lock.lock();
        try {
            httpSession = request.getSession();
            // 更新成已参赛状态
            int count = matchTableService.updateMatchByMatchNoAndMatchUserId(MatchConstant.MATCH_FLAG_Y, matchNo, userId);
            if (count > 0) {
                httpSession.setAttribute("userAgree", "已同意该球员的申请");
                return "redirect:requestList";
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        } finally {
            lock.unlock();
        }
        return "error";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [request, response]
     * @author Administrator
     * @createTime 2020/6/2 13:59
     * @description 统计球员得分结果, 进行展示 TODO
     */
    @RequestMapping(value = {"/statisticalScore"})
    public String adminStatisticalPlayerScore(HttpServletRequest request, HttpServletResponse response) {
        try {
            List<Score> scoreList = scoreService.findAll();

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "error";
    }

    /**
     * @return java.lang.String
     * @throws
     * @params []
     * @author Administrator
     * @createTime 2020/6/2 14:17
     * @description 安排球员比赛, 此处不考虑裁判不足的情况 TODO
     */
    @RequestMapping(value = {"/scheduleGame"})
    public String adminSchedulePlayerGame(HttpServletRequest request, HttpServletResponse response) {
        try {
            httpSession = request.getSession();
            // 从参赛表中查询出所有的参赛人员的数据信息
            List<MatchTable> matchList = matchTableService.findMatchByMatchFlag(MatchConstant.MATCH_FLAG_Y);
            if (matchList.size() < 2) {
                httpSession.setAttribute("sgInfo", "该场比赛人员不足，无法安排");
                return "gameResult";
            }
            Map<String, JSONObject> maps = new HashMap<>(6);
            // 查询出所有的裁判人员
            List<User> refereeLists = userService.findUserByUserRoleId(UserConstant.USER_ROLE_REFEREE);
            Map<String, List<String>> mapNo = this.getEqualsMatchNo(matchList);
            Set<String> keySet = mapNo.keySet();
            synchronized (this) {
                keySet.stream().forEach(item -> {
                    Random random = new Random();
                    int index = random.nextInt(refereeLists.size());
                    User user = refereeLists.get(index);
                    try {
                        Integer result = matchTableService.updateMatchRefereeByMatchNo(user.getUserId(), user.getUserName(), item);
                        if (result > 0) {
                            // 把集合中matchTables报名参加统一场比赛的人员进行排赛,进行排赛操作
                            List<String> list = mapNo.get(item);
                            JSONObject jsonObject = new JSONObject();
                            for (int i = 0; i < list.size(); i++) {
                                String key = list.get(i);
                                StringBuilder sb = null;
                                for (int j = i + 1; j < list.size(); j++) {
                                    sb = new StringBuilder(list.get(j)).append("&");
                                    if (jsonObject.containsKey(key)) {
                                        String value = (String) jsonObject.get(key);
                                        sb.append(value);
                                    }
                                    jsonObject.put(key, sb.toString());
                                }
                            }
                            maps.put(item, jsonObject);
                        }
                    } catch (Exception e) {
                        LOGGER.error(e.getMessage(), e);
                    }
                });
                Map<String, List<String>> mapList = new HashMap<>(8);
                Set<String> keySet1 = maps.keySet();
                keySet1.stream().forEach(ks -> {
                    List<String> list = new ArrayList<>();
                    JSONObject jsonObject = maps.get(ks);
                    Set<String> keySet2 = jsonObject.keySet();
                    keySet2.stream().forEach(ks2 -> {
                        String str = (String) jsonObject.get(ks2);
                        String substring = str.substring(0, str.length() - 1);
                        if (!substring.contains("&")) {
                            list.add(ks2 + " PK " + substring);
                        }
                        if (substring.contains("&")) {
                            String[] split = substring.split("&");
                            for (int i = 0; i < split.length; i++) {
                                list.add(ks2 + " PK " + split[i]);
                            }
                        }
                    });
                    mapList.put(ks, list);
                });
                LOGGER.info(StringUtils.formatString(" maps Param Is ", maps.toString()));
                LOGGER.info(StringUtils.formatString(" mapList Param Is ", mapList.toString()));
                httpSession.setAttribute("gameSchedule", mapList);
                return "scheduleGame";
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "err500";
    }

    private Map<String, List<String>> getEqualsMatchNo(List<MatchTable> matchList) {
        lock.lock();
        try {
            Map<String, List<String>> maps = new HashMap<String, List<String>>(16);
            for (int i = 0; i < matchList.size(); i++) {
                List<String> lists = new ArrayList<>();
                MatchTable matchTable = matchList.get(i);
                String matchNo = matchTable.getMatchNo();
                for (int j = 0; j < matchList.size(); j++) {
                    MatchTable matchTable1 = matchList.get(j);
                    String matchNo1 = matchTable1.getMatchNo();
                    if (matchNo.equalsIgnoreCase(matchNo1)) {
                        lists.add(String.valueOf(matchTable1.getMatchUserId()));
                    }
                }
                if (lists.size() > 2) {
                    maps.put(matchNo, lists);
                }
            }
            return maps;
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        } finally {
            lock.unlock();
        }
        return null;
    }

    /**
     * @return java.lang.String
     * @throws
     * @params []
     * @author Administrator
     * @createTime 2020/6/2 15:45
     * @description 超级管理查看比赛信息，包括比赛名称，比赛人员，该场的裁判，比赛结果
     * {"gameName":"擂台赛","contest":{"A":{"userName":"LLY","sumResult":"3"},"B":{"userName":"YIY","sumResult":"2"}},"referee":"CPY"}
     */
    @RequestMapping(value = {"/viewGameResult"})
    public String superAdminViewGameInfo(HttpServletRequest request, HttpServletResponse response) {
        try {
            httpSession = request.getSession();
            // 查询所有的比赛结果
            List<Score> scoreLists = scoreService.findAll();
            // List<Map<String, Object>> maps = this.recursiveAnalysisJson(scoreLists);
            List<Player> players = new ArrayList<>();
            scoreLists.stream().forEach(item -> {
                String jsonData = item.getScoreBureauResult();
                Player player = this.recursiveAnalysisJsonByStr(jsonData);
                player.setGameNo(item.getScoreGameNo());
                players.add(player);
            });
            httpSession.setAttribute("playerLists", players);
            return "viewGameResult";
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "err500";
    }


    private Player recursiveAnalysisJsonByStr(String jsonData) {
        JSONObject jsonObject = JSONObject.parseObject(jsonData);
        // 比赛名称
        String gameName = (String) jsonObject.get("gameName");
        // 参赛者
        JSONObject contest = (JSONObject) jsonObject.get("contest");
        // 选手一
        JSONObject jsonA = (JSONObject) contest.get("A");
        String jsonAUserName = (String) jsonA.get("userName");
        String jsonASumResult = (String) jsonA.get("sumResult");

        // 选手二
        JSONObject jsonB = (JSONObject) contest.get("B");
        String jsonBUserName = (String) jsonB.get("userName");
        String jsonBSumResult = (String) jsonB.get("sumResult");

        // 裁判员
        String referee = (String) jsonObject.get("referee");
        Player player = new Player();
        player.setGameName(gameName);
        player.setPlayerAUserName(jsonAUserName);
        player.setPlayerASumResult(jsonASumResult);
        player.setPlayerBUserName(jsonBUserName);
        player.setPlayerBSumResult(jsonBSumResult);
        player.setReferee(referee);
        return player;
    }

    /**
     * @return java.lang.String
     * @throws
     * @params [jsonObject]
     * @author Administrator
     * @createTime 2020/6/2 17:18
     * @description 递归解析json
     */
    private List<List<Map<String, Object>>> recursiveAnalysisJson(List<Score> scoreLists) {
        try {
            List<List<Map<String, Object>>> lists = new ArrayList<>();
            scoreLists.stream().forEach(item -> {
                String jsonData = item.getScoreBureauResult();
                JSONObject jsonObject = JSONObject.parseObject(jsonData);
                Map<String, Object> m = new HashMap<>();
                m.put("gameNo", item.getScoreGameNo());
                m.put("referee", item.getScoreRefereeName());
                List<Map<String, Object>> l = new ArrayList<>();
                l.add(m);
                List<Map<String, Object>> maps = recursiveAnalysisJson(jsonObject.toJSONString());
                lists.add(maps);
                lists.add(l);
            });
            return lists;
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return null;
    }

    private List<Map<String, Object>> recursiveAnalysisJson(String jsonString) {
        try {
            List<Map<String, Object>> jsonList = new ArrayList<>();
            JSONObject jsonObject = JSONObject.parseObject(jsonString);
            Set<String> keys = jsonObject.keySet();
            keys.stream().forEach(key -> {
                JSONObject jsonObject1 = JSONObject.parseObject(jsonObject.get(key).toString());
                Set<String> keySet = jsonObject1.keySet();
                Map<String, Object> maps = new HashMap<>(6);
                keySet.stream().forEach(ks -> {
                    List<String> lists = new ArrayList<>();
                    JSONObject jo = (JSONObject) jsonObject1.get(ks);
                    lists.add(jo.get("userId").toString());
                    lists.add(jo.get("userName").toString());
                    lists.add(jo.get("scoreResult").toString());
                    lists.add(jo.get("flag").toString());
                    maps.put(ks, lists);
                });
                jsonList.add(maps);
            });
            return jsonList;
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return null;
    }
}
