package com.csh.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/3
 * @descript 重定向页面
 * @package com.csh.controller
 */
@Controller
@RequestMapping(value = "/redirect")
public class RedirectController {

    @RequestMapping(value = {"/makeRequest"})
    public String userProfile() {
        return "makeRequest";
    }

}
