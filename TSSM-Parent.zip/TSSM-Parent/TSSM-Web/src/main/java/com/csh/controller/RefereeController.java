package com.csh.controller;

import com.csh.constant.match.MatchConstant;
import com.csh.pojo.MatchTable;
import com.csh.pojo.Score;
import com.csh.pojo.User;
import com.csh.service.MatchTableService;
import com.csh.service.ScoreService;
import com.csh.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 裁判员相关操作
 * @package com.csh.controller
 */
@Controller
@RequestMapping(value = {"/referee"})
public class RefereeController {

    private static final Logger LOGGER = LoggerFactory.getLogger(RefereeController.class);

    private HttpSession httpSession;

    @Autowired
    private ScoreService scoreService;

    @Autowired
    private UserService userService;

    @Autowired
    private MatchTableService matchTableService;

    /**
     * @return java.lang.String
     * @throws
     * @params [scoreUserId, scoreGameNo, refereeId, scoreFraction, jsonObject, request, response]
     * @author Administrator
     * @createTime 2020/6/2 15:56
     * @description 裁判员进行比赛评分, refereeId为裁判员的userId
     * jsonObject 格式
     * {"gameName":"擂台赛","contest":{"A":{"userName":"LLY","sumResult":"3"},"B":{"userName":"YIY","sumResult":"2"}},"referee":"CPY"}
     * {'gameName':'123XXFDEZ','contest':{'A':{'userName':'test-player1','sumResult':'1'},'B':{'userName':'tp5','sumResult':'2'}},'referee':'tp1'}
     */
    @RequestMapping(value = {"/refereeScore"}, method = RequestMethod.GET, produces = {"application/json;charset=utf8"})
    public String refereeScore(@RequestParam("matchNo") String matchNo, @RequestParam("refereeId") String refereeId, @RequestParam("userPlayerIdA") String userPlayerIdA,
                               @RequestParam("scoreBureauResultA") String scoreBureauResultA,
                               @RequestParam("userPlayerIdB") String userPlayerIdB, @RequestParam("scoreBureauResultB") String scoreBureauResultB,
                               HttpServletRequest request, HttpServletResponse response, Model model) {
        try {
            httpSession = request.getSession();
            // 裁判员
            User referee = userService.findUserByUserId(Integer.valueOf(refereeId));
            // 球员
            User playerA = userService.findUserByUserId(Integer.valueOf(userPlayerIdA));
            // 球员B
            User playerB = userService.findUserByUserId(Integer.valueOf(userPlayerIdB));
            // 创建一个对象
            Score score = new Score();
            score.setScoreGameNo(matchNo);
            score.setScoreRefereeName(referee.getUserName());
            if (Integer.valueOf(scoreBureauResultA) > Integer.valueOf(scoreBureauResultB)) {
                score.setScoreUserId(Integer.valueOf(userPlayerIdA));
                score.setScoreFraction(Integer.valueOf(scoreBureauResultA));
                score.setScoreUserName(playerA.getUserName());
                score.setScoreRefereeId(Integer.valueOf(refereeId));
            } else {
                score.setScoreUserId(Integer.valueOf(userPlayerIdB));
                score.setScoreFraction(Integer.valueOf(scoreBureauResultB));
                score.setScoreUserName(playerB.getUserName());
                score.setScoreRefereeId(Integer.valueOf(refereeId));
            }
            String json = "{'gameName':'" + matchNo + "','contest':{'A':{'userName':'" + playerA.getUserName() + "','sumResult':'" + scoreBureauResultA + "'},'B':{'userName':'" + playerB.getUserName() + "','sumResult':'" + scoreBureauResultB + "'}},'referee':'" + referee.getUserName() + "'}";
            score.setScoreBureauResult(json);
            int count = scoreService.insertScore(score);
            if (count > 0) {
                // 更新比赛的状态为结束
                matchTableService.updateMatchByMatchNoAndMatchUserId(MatchConstant.MATCH_FLAG_E, matchNo, Integer.valueOf(userPlayerIdA));
                model.addAttribute("refereeScore", "比赛结果已提交");
                return "statisticalScore";
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "err500";
    }


    /**
     * @return java.lang.String
     * @throws
     * @params [request, response]
     * @author Administrator
     * @createTime 2020/6/4 12:25
     * @description 比赛评分页面
     */
    @RequestMapping(value = {"/statisticalScore"}, method = RequestMethod.GET)
    public String statisticalScore(HttpServletRequest request, HttpServletResponse response, Model model) {
        try {
            httpSession = request.getSession();
            List<MatchTable> matchIngLists = matchTableService.findMatchByMatchFlag(MatchConstant.MATCH_FLAG_ING);
            List<String> lists = new ArrayList<>();
            int size = matchIngLists.size();
            for (int i = 0; i < size; i++) {
                MatchTable matchTable = matchIngLists.get(i);
                for (int j = i + 1; j < size; j++) {
                    MatchTable matchTable1 = matchIngLists.get(j);
                    if (!matchTable.getMatchUserName().equalsIgnoreCase(matchTable1.getMatchUserName())) {
                        // 自己不能和自己比
                        lists.add(matchTable1.getMatchNo() + "&" + matchTable.getMatchUserId() + "&" + matchTable1.getMatchUserId() + "&" + matchTable.getMatchRefereeId());
                        break;
                    }
                }
                break;
            }
            LOGGER.info(lists.toString());
            httpSession.setAttribute("matchIngLists", lists);
            httpSession.setAttribute("matchflag", "暂无正在进行的比赛");
            return "statisticalScore";
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return "err500";
    }
}
