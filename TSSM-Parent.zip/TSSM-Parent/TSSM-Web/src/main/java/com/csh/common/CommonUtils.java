package com.csh.common;

import com.csh.pojo.MatchTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/5
 * @descript 一些共用方法
 * @package com.csh.common
 */
public class CommonUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtils.class);

    private static Object obj = new Object();

    public static Map<String, List<String>> getEqualsMatchNo(List<MatchTable> matchList) {
        try {
            Map<String, List<String>> maps = new HashMap<String, List<String>>(16);
            synchronized (obj) {
                for (int i = 0; i < matchList.size(); i++) {
                    List<String> lists = new ArrayList<>();
                    MatchTable matchTable = matchList.get(i);
                    String matchNo = matchTable.getMatchNo();
                    for (int j = 0; j < matchList.size(); j++) {
                        MatchTable matchTable1 = matchList.get(j);
                        String matchNo1 = matchTable1.getMatchNo();
                        if (matchNo.equalsIgnoreCase(matchNo1)) {
                            lists.add(String.valueOf(matchTable1.getMatchUserId()));
                        }
                    }
                    if (lists.size() > 2) {
                        maps.put(matchNo, lists);
                    }
                }
            }
            return maps;
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return null;
    }
}
