package com.csh;

import com.csh.utils.MD5Utils;

import java.math.BigInteger;
import java.security.MessageDigest;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/3
 * @descript 测试
 * @package com.csh
 */
public class AppTest {
    //    @Test
    /*public void shouldAnswerWithTrue() {
        String jsonObject = "{\n" +
                "    \"first\":{\n" +
                "        \"A\":{\n" +
                "            \"userId\":\"123\",\n" +
                "            \"userName\":\"csh\",\n" +
                "            \"scoreResult\":\"1\",\n" +
                "            \"flag\":\"Y\"\n" +
                "        },\n" +
                "        \"B\":{\n" +
                "            \"userId\":\"123\",\n" +
                "            \"userName\":\"csh\",\n" +
                "            \"scoreResult\":\"1\",\n" +
                "            \"flag\":\"N\"\n" +
                "        }\n" +
                "    },\n" +
                "    \"second\":{\n" +
                "        \"A\":{\n" +
                "            \"userId\":\"123\",\n" +
                "            \"userName\":\"csh\",\n" +
                "            \"scoreResult\":\"1\",\n" +
                "            \"flag\":\"N\"\n" +
                "        },\n" +
                "        \"B\":{\n" +
                "            \"userId\":\"123\",\n" +
                "            \"userName\":\"csh\",\n" +
                "            \"scoreResult\":\"1\",\n" +
                "            \"flag\":\"Y\"\n" +
                "        }\n" +
                "    },\n" +
                "    \"third\":{\n" +
                "        \"A\":{\n" +
                "            \"userId\":\"123\",\n" +
                "            \"userName\":\"csh\",\n" +
                "            \"scoreResult\":\"1\",\n" +
                "            \"flag\":\"Y\"\n" +
                "        },\n" +
                "        \"B\":{\n" +
                "            \"userId\":\"123\",\n" +
                "            \"userName\":\"csh\",\n" +
                "            \"scoreResult\":\"1\",\n" +
                "            \"flag\":\"N\"\n" +
                "        }\n" +
                "    },\n" +
                "    \"gameName\":\"gameName\"\n" +
                "}\n";
        AppTest.recursiveAnalysisJson(jsonObject);
    }

    private static String recursiveAnalysisJson(String jsonString) {
        List<Map<String, Object>> jsonList = new ArrayList<>();
        JSONObject jsonObject = JSONObject.parseObject(jsonString);
        jsonObject.remove("gameName");
        Set<String> keys = jsonObject.keySet();
        keys.stream().forEach(key -> {
            JSONObject jsonObject1 = JSONObject.parseObject(jsonObject.get(key).toString());
            Set<String> keySet = jsonObject1.keySet();
            Map<String, Object> maps = new HashMap<>(6);
            keySet.stream().forEach(ks -> {
                List<String> lists = new ArrayList<>();
                JSONObject jo = (JSONObject) jsonObject1.get(ks);
                lists.add(jo.get("userId").toString());
                lists.add(jo.get("userName").toString());
                lists.add(jo.get("scoreResult").toString());
                lists.add(jo.get("flag").toString());
                maps.put(ks, lists);
            });
            jsonList.add(maps);
        });
        return "";
    }
*/
//    @Test
    public void test() throws Exception {
        MessageDigest md5 = MessageDigest.getInstance("md5");
        md5.update("userName".getBytes());
        String s = new BigInteger(1, md5.digest()).toString(16);
        System.out.println(s);
        System.out.println("=====================================");

    }

    /***
     * MD5加码 生成32位md5码
     */
    public static String string2MD5(String inStr) {
        MessageDigest md5 = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (Exception e) {
            System.out.println(e.toString());
            e.printStackTrace();
            return "";
        }
        char[] charArray = inStr.toCharArray();
        byte[] byteArray = new byte[charArray.length];

        for (int i = 0; i < charArray.length; i++) {
            byteArray[i] = (byte) charArray[i];
        }
        byte[] md5Bytes = md5.digest(byteArray);
        StringBuffer hexValue = new StringBuffer();
        for (int i = 0; i < md5Bytes.length; i++) {
            int val = ((int) md5Bytes[i]) & 0xff;
            if (val < 16) {
                hexValue.append("0");
            }
            hexValue.append(Integer.toHexString(val));
        }
        return hexValue.toString();

    }

    /**
     * 加密解密算法 执行一次加密，两次解密
     */
    public static String convertMD5(String inStr) {

        char[] a = inStr.toCharArray();
        for (int i = 0; i < a.length; i++) {
            a[i] = (char) (a[i] ^ 't');
        }
        String s = new String(a);
        return s;
    }

    // 测试主函数
    public static void main(String args[]) {
        String s = "username";
        System.out.println("MD5后：" + MD5Utils.string2MD5(s));
        System.out.println("解密的：" + MD5Utils.convertMD5(MD5Utils.convertMD5(s)));
    }
}
