package com.csh.dao;

import com.csh.pojo.Score;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 分数Dao
 * @package com.csh.dao
 */
@Repository
public interface ScoreDao {

    /**
     * @return java.util.List<com.csh.pojo.Score>
     * @throws Exception
     * @params []
     * @author Administrator
     * @createTime 2020/6/2 9:10
     * @description 查询所有的分数，仅管理员有权限
     */
    @Select(value = "select * from score group by scoreUserId, scoreGameNo order by scoreFraction desc")
    List<Score> findAll() throws Exception;

    /**
     * @return com.csh.pojo.Score
     * @throws Exception
     * @params [userId, gameId]
     * @author Administrator
     * @createTime 2020/6/2 9:16
     * @description 查询个人单场比赛分数
     */
    @Select(value = "select * from score where scoreUserId = #{userId} and scoreGameNo = #{gameNo}")
    Score findScoreByUserIdAndGameNo(@Param("userId") int userId, @Param("gameNo") String gameNo) throws Exception;

    /**
     * @return java.util.List<com.csh.pojo.Score>
     * @throws Exception
     * @params [userId]
     * @author Administrator
     * @createTime 2020/6/2 9:16
     * @description 查询个人所有的比赛分数
     */
    @Select(value = "select * from score where scoreUserId = #{userId}")
    List<Score> findAllScoreByUserId(int userId) throws Exception;

    /**
     * @return int
     * @throws
     * @params [score]
     * @author Administrator
     * @createTime 2020/6/2 15:17
     * @description 添加分数信息
     */
    @Insert(value = "insert into score (scoreUserId, scoreGameNo, scoreFraction, scoreUserName, scoreRefereeId, scoreRefereeName, scoreBureauResult) values (#{scoreUserId}, #{scoreGameNo}, #{scoreFraction}, #{scoreUserName}, #{scoreRefereeId}, #{scoreRefereeName}, #{scoreBureauResult})")
    int insertScore(Score score) throws Exception;
}
