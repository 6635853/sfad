package com.csh.dao;

import com.csh.pojo.User;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Adminstrator
 * @version 1.0
 * @date 2020/6/1
 * @descript 用户Dao
 * @package com.bill.dao
 */
@Repository
public interface UserDao {

    /**
     * @return java.util.List<com.bill.pojo.Users>
     * @throws Exception
     * @params []
     * @author Adminstrator
     * @createTime 2020/6/1 15:42
     * @description 查询所有的用户
     */
    @Select(value = "select * from user")
    List<User> findAllUser() throws Exception;

    /**
     * @return com.bill.pojo.Users
     * @throws Exception
     * @params [id]
     * @author Adminstrator
     * @createTime 2020/6/1 15:02
     * @description 根据id查询用户
     */
    @Select(value = "select * from user where userId = #{userId}")
    User findUserByUserId(Integer userId) throws Exception;

    /**
     * @return com.bill.pojo.Users
     * @throws Exception
     * @params [userName, password]
     * @author Adminstrator
     * @createTime 2020/6/1 15:03
     * @description 根据用户名和密码查找用户
     */
    @Select(value = "select * from user where userName = #{userName} and userPassword = #{userPassword}")
    User findUserByUserNameAndUserPassword(@Param("userName") String userName, @Param("userPassword") String userPassword) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [users]
     * @author Adminstrator
     * @createTime 2020/6/1 15:04
     * @description 添加用户
     */
    @Insert(value = "insert into user (userName,userPassword,userPhone,userEmail,userPlayerId,userRoleId,createdTime) values (#{userName}, #{userPassword}, #{userPhone}, #{userEmail}, #{userPlayerId}, #{userRoleId}, #{createdTime})")
    int insertUser(User user) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [users]
     * @author Adminstrator
     * @createTime 2020/6/1 15:04
     * @description 根据用户id修改用户
     */
    @Update(value = "update user set userName = #{userName}, userPassword = #{userPassword}, userPhone = #{userPhone}, userEmail = #{userEmail} where userId = #{userId}")
    int updateUserByUser(User user) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [id]
     * @author Adminstrator
     * @createTime 2020/6/1 15:35
     * @description 删除一个用户
     */
    @Delete(value = "delete from user where userId = #{userId}")
    int deleteUserByUserId(Integer userId) throws Exception;


    /**
     * @return java.util.List<com.csh.pojo.User>
     * @throws Exception
     * @params [roleId]
     * @author Administrator
     * @createTime 2020/6/2 14:30
     * @description 根据角色查询用户
     */
    @Select(value = "select * from user where userRoleId = #{userRoleId}")
    List<User> findUserByUserRoleId(Integer roleId) throws Exception;
}
