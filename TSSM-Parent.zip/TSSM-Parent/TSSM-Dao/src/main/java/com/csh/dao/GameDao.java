package com.csh.dao;

import com.csh.pojo.Game;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 赛程Dao
 * @package com.csh.dao
 */
@Repository
public interface GameDao {

    /**
     * @return List<Game>
     * @throws
     * @params [gameFlag]
     * @author Administrator
     * @createTime 2020/6/4 0:17
     * @description 查看所有的赛程信息
     */
    @Select(value = "select * from game where gameFlag = #{gameFlag} and gameTime > SYSDATE() order by gameTime ASC")
    List<Game> findAll(String gameFlag) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [game]
     * @author Administrator
     * @createTime 2020/6/2 8:59
     * @description 添加赛程信息
     */
    @Select(value = "insert into game (gameName, gameAddress, gameTime, gameAnnouncer, gameNo, gameFlag, gameSponsor, gameRefereeName, gameRefereeId) values (#{gameName}, #{gameAddress}, #{gameTime}, #{gameAnnouncer}, #{gameNo}, #{gameFlag}, #{gameSponsor}, #{gameRefereeName}, #{gameRefereeId})")
    Integer insertGame(Game game) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [game]
     * @author Administrator
     * @createTime 2020/6/2 9:00
     * @description 修改赛程信息
     */
    @Update(value = "update game set gameAddress = #{gameAddress}, gameTime = SYSDATE(), gameAnnouncer = #{gameAnnouncer} where gameId = #{gameId}")
    Integer updateGame(Game game) throws Exception;

    /**
     * @return com.csh.pojo.Game
     * @throws
     * @params [gameId]
     * @author Administrator
     * @createTime 2020/6/2 16:44
     * @description 根据id查询单个比赛
     */
    @Select(value = "select * from game where gameId = #{gameId}")
    Game findGameByGameId(int gameId) throws Exception;

    /**
     * @return com.csh.pojo.Game
     * @throws
     * @params [gameNo]
     * @author Administrator
     * @createTime 2020/6/2 16:44
     * @description 根据id查询单个比赛
     */
    @Select(value = "select * from game where gameNo = #{gameNo}")
    Game findGameByGameNo(String gameNo) throws Exception;
}
