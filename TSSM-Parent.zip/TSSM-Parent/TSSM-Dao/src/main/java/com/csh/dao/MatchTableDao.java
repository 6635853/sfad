package com.csh.dao;

import com.csh.pojo.MatchTable;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 比赛Dao
 * @package com.csh.dao
 */
@Repository
public interface MatchTableDao {

    /**
     * @return java.util.List<com.csh.pojo.MatchTable>
     * @throws
     * @params []
     * @author Administrator
     * @createTime 2020/6/2 12:11
     * @description 查询所有的比赛信息
     */
    @Select(value = "select * from matchtabel")
    List<MatchTable> findAllMatch() throws Exception;

    /**
     * @return java.util.List<com.csh.pojo.MatchTable>
     * @throws
     * @params [matchFlag]
     * @author Administrator
     * @createTime 2020/6/2 12:15
     * @description 参加比赛的球员
     */
    @Select(value = "select * from matchTable where matchFlag = #{matchFlag} and matchTime > SYSDATE() order by matchTime desc")
    List<MatchTable> findMatchByMatchFlag(String matchFlag) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [matchTable]
     * @author Administrator
     * @createTime 2020/6/2 9:53
     * @description 保存一场赛事
     */
    @Insert(value = "insert into matchTable (matchNo,matchUserId,matchUserName,matchRefereeId,matchRefereeName,matchFlag,matchTime) values (#{matchNo}, #{matchUserId}, #{matchUserName}, #{matchRefereeId}, #{matchRefereeName}, #{matchFlag}, #{matchTime})")
    int insertMatchTable(MatchTable matchTable) throws Exception;

    /**
     * @return com.csh.pojo.MatchTable
     * @throws Exception
     * @params [userId, gameNo]
     * @author Administrator
     * @createTime 2020/6/2 11:13
     * @description 查询是否有信息，以此判断是否参加过比赛
     */
    @Select(value = "select * from matchtable where matchUserId = #{userId} and matchNo = #{gameNo}")
    MatchTable findMatchByUserIdAndMatchNo(@Param("userId") int userId, @Param("gameNo") String gameNo) throws Exception;

    /**
     * @return com.csh.pojo.MatchTable
     * @throws Exception
     * @params [userId, gameNo]
     * @author Administrator
     * @createTime 2020/6/2 11:13
     * @description 某个球员已经参加的比赛
     */
    @Select(value = "select * from matchtable where matchUserId = #{userId} and matchFlag = #{matchFlag}")
    List<MatchTable> findMatchByUserIdAndMatchFlag(@Param("userId") Integer userId, @Param("matchFlag") String matchFlag) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [matchNo, matchUserId]
     * @author Administrator
     * @createTime 2020/6/2 12:38
     * @description 更新用户参赛状态
     */
    @Update(value = "update matchtable set matchFlag = #{matchFlag} where matchNo = #{matchNo} and matchUserId = #{matchUserId}")
    Integer updateMatchByMatchNoAndMatchUserId(@Param("matchFlag") String matchFlag, @Param("matchNo") String matchNo, @Param("matchUserId") Integer matchUserId) throws Exception;

    /**
     * @return java.lang.Integer
     * @throws
     * @params [matchFlag, matchNo]
     * @author Administrator
     * @createTime 2020/6/5 18:02
     * @description 根据matchNo更新matchFlag
     */
    @Update(value = "update matchtable set matchFlag = #{matchFlag} where matchNo = #{matchNo} and matchUserId = #{matchUserId}")
    Integer updateMatchFlagByMatchNo(@Param("matchFlag") String matchFlag, @Param("matchNo") String matchNo) throws Exception;

    /**
     * @return int
     * @throws
     * @params [matchFlag, matchNo, matchUserId]
     * @author Administrator
     * @createTime 2020/6/4 17:47
     * @description 分配裁判
     */
    @Update(value = "update matchtable set matchRefereeId = #{matchRefereeId}, matchRefereeName = #{matchRefereeName} where matchNo = #{matchNo}")
    Integer updateMatchRefereeByMatchNo(@Param("matchRefereeId") Integer matchRefereeId, @Param("matchRefereeName") String matchRefereeName, @Param("matchNo") String matchNo) throws Exception;
}
