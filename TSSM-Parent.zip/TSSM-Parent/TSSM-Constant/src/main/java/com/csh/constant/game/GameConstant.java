package com.csh.constant.game;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 赛程常量
 * @package com.csh.constant.game
 */
public class GameConstant {

    // 已结束
    public static final String GAME_FLAG_Y = "Y";

    // 未开始
    public static final String GAME_FLAG_N = "N";
}
