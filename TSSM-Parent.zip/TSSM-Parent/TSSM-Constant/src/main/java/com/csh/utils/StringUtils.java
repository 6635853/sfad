package com.csh.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/3
 * @descript Stirng 帮助类
 * @package com.csh.utils
 */
public class StringUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(StringUtils.class);

    /**
     * @return java.lang.String
     * @throws
     * @params [info, params]
     * @author csh
     * @createTime 2020/6/3 21:29
     * @description 格式化字符串消息
     */
    public static String formatString(String info, Object... params) {
        if (params.length < 0) {
            return null;
        }
        StringBuilder sbInfo = new StringBuilder();
        StringBuilder paramInfo = new StringBuilder();
        for (int i = 0; i < params.length; i++) {
            sbInfo.append("{" + i + "} ");
            paramInfo.append(params[i]).append(", ");
        }
        String format = MessageFormat.format(info + sbInfo.toString(), paramInfo.toString());
        return format;
    }

}
