package com.csh.constant.match;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 比赛常量
 * @package com.csh.constant.match
 */
public class MatchConstant {

    // 已参赛
    public static final String MATCH_FLAG_Y = "Y";

    // 未参赛
    public static final String MATCH_FLAG_N = "N";

    // 已结束
    public static final String MATCH_FLAG_E = "END";

    // 进行中
    public static final String MATCH_FLAG_ING = "ING";
}
