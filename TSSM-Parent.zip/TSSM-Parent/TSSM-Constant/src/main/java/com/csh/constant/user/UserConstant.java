package com.csh.constant.user;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 用户常量
 * @package com.csh.constant.user
 */
public class UserConstant {

    // 球员
    public static final Integer USER_ROLE_PLAYER = 1;

    // 裁判员
    public static final Integer USER_ROLE_REFEREE = 2;

    // 管理员
    public static final Integer USER_ROLE_ADMIN = 3;

    // 超级管理员
    public static final Integer USER_ROLE_ROOT = 4;
}
