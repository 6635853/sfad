package com.csh.service.impl;

import com.csh.dao.MatchTableDao;
import com.csh.pojo.MatchTable;
import com.csh.service.MatchTableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author csh
 * @version 1.0
 * @date 2020/6/2
 * @descript MatchTable业务实现类
 * @package com.csh.service.impl
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class MatchTableServiceImpl implements MatchTableService {

    @Autowired
    private MatchTableDao matchTableDao;

    @Override
    public int insertMatchTable(MatchTable matchTable) throws Exception {
        return matchTableDao.insertMatchTable(matchTable);
    }

    @Override
    public MatchTable findMatchByUserIdAndMatchNo(Integer userId, String gameNo) throws Exception {
        return matchTableDao.findMatchByUserIdAndMatchNo(userId, gameNo);
    }

    @Override
    public Integer updateMatchByMatchNoAndMatchUserId(String matchFlag, String matchNo, Integer matchUserId) throws Exception {
        return matchTableDao.updateMatchByMatchNoAndMatchUserId(matchFlag, matchNo, matchUserId);
    }

    @Override
    public Integer updateMatchRefereeByMatchNo(Integer matchRefereeId, String matchRefereeName, String matchNo) throws Exception {
        return matchTableDao.updateMatchRefereeByMatchNo(matchRefereeId, matchRefereeName, matchNo);
    }

    @Override
    public List<MatchTable> findMatchByUserIdAndMatchFlag(Integer userId, String matchFlag) throws Exception {
        return matchTableDao.findMatchByUserIdAndMatchFlag(userId, matchFlag);
    }

    @Override
    public Integer updateMatchFlagByMatchNo(String matchFlag, String matchNo) throws Exception {
        return matchTableDao.updateMatchFlagByMatchNo(matchFlag, matchNo);
    }

    @Override
    public List<MatchTable> findAllMatch() throws Exception {
        return matchTableDao.findAllMatch();
    }

    @Override
    public List<MatchTable> findMatchByMatchFlag(String matchFlag) throws Exception {
        return matchTableDao.findMatchByMatchFlag(matchFlag);
    }


}
