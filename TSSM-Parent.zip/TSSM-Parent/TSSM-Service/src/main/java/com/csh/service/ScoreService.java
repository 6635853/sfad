package com.csh.service;

import com.csh.pojo.Score;

import java.util.List;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 比赛分数业务
 * @package com.csh.service
 */
public interface ScoreService {

    /**
     * @return java.util.List<com.csh.pojo.Score>
     * @throws
     * @params []
     * @author Administrator
     * @createTime 2020/6/2 9:10
     * @description 查询所有的分数，仅管理员有权限
     */
    List<Score> findAll() throws Exception;

    /**
     * @return com.csh.pojo.Score
     * @throws
     * @params [userId, gameId]
     * @author Administrator
     * @createTime 2020/6/2 9:16
     * @description 查询个人单场比赛分数
     */
    Score findScoreByUserIdAndGameNo(int userId, String gameNo) throws Exception;

    /**
     * @return java.util.List<com.csh.pojo.Score>
     * @throws
     * @params [userId]
     * @author Administrator
     * @createTime 2020/6/2 9:16
     * @description 查询个人所有的比赛分数
     */
    List<Score> findAllScoreByUserId(int userId) throws Exception;

    /**
     * @return int
     * @throws
     * @params [score]
     * @author Administrator
     * @createTime 2020/6/2 15:17
     * @description 添加分数信息
     */
    int insertScore(Score score) throws Exception;
}
