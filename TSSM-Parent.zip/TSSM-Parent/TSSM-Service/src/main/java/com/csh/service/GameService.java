package com.csh.service;

import com.csh.pojo.Game;

import java.util.List;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript 赛事信息业务
 * @package com.csh.service
 */
public interface GameService {
    /**
     * @return java.util.List<com.csh.pojo.Game>
     * @throws
     * @params [gameFlag]
     * @author Administrator
     * @createTime 2020/6/4 0:17
     * @description 查看所有的赛程信息
     */
    List<Game> findAll(String gameFlag) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [game]
     * @author Administrator
     * @createTime 2020/6/2 8:59
     * @description 添加赛程信息
     */
    Integer insertGame(Game game) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [game]
     * @author Administrator
     * @createTime 2020/6/2 9:00
     * @description 修改赛程信息
     */
    Integer updateGame(Game game) throws Exception;

    /**
     * @return com.csh.pojo.Game
     * @throws
     * @params [gameId]
     * @author Administrator
     * @createTime 2020/6/2 16:44
     * @description 根据id查询单个比赛
     */
    Game findGameByGameId(int gameId) throws Exception;

    /**
     * @return com.csh.pojo.Game
     * @throws
     * @params [gameNo]
     * @author Administrator
     * @createTime 2020/6/2 16:44
     * @description 根据id查询单个比赛
     */
    Game findGameByGameNo(String gameNo) throws Exception;
}
