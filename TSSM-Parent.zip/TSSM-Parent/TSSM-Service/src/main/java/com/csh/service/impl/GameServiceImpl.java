package com.csh.service.impl;

import com.csh.dao.GameDao;
import com.csh.pojo.Game;
import com.csh.service.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author csh
 * @version 1.0
 * @date 2020/6/2
 * @descript 赛事信息实现
 * @package com.csh.service.impl
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class GameServiceImpl implements GameService {

    @Autowired
    private GameDao gameDao;

    @Override
    public List<Game> findAll(String gameFlag) throws Exception {
        return gameDao.findAll(gameFlag);
    }

    @Override
    public Integer insertGame(Game game) throws Exception {
        return gameDao.insertGame(game);
    }

    @Override
    public Integer updateGame(Game game) throws Exception {
        return gameDao.updateGame(game);
    }

    @Override
    public Game findGameByGameId(int gameId) throws Exception {
        return gameDao.findGameByGameId(gameId);
    }

    @Override
    public Game findGameByGameNo(String gameNo) throws Exception {
        return gameDao.findGameByGameNo(gameNo);
    }
}
