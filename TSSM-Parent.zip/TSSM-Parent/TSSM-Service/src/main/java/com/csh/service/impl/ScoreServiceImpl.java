package com.csh.service.impl;

import com.csh.dao.ScoreDao;
import com.csh.pojo.Score;
import com.csh.service.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author csh
 * @version 1.0
 * @date 2020/6/2
 * @descript 比赛分数业务实现
 * @package com.csh.service.impl
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class ScoreServiceImpl implements ScoreService {

    @Autowired
    private ScoreDao scoreDao;

    @Override
    public List<Score> findAll() throws Exception {
        return scoreDao.findAll();
    }

    @Override
    public Score findScoreByUserIdAndGameNo(int userId, String gameNo) throws Exception {
        return scoreDao.findScoreByUserIdAndGameNo(userId, gameNo);
    }

    @Override
    public List<Score> findAllScoreByUserId(int userId) throws Exception {
        return scoreDao.findAllScoreByUserId(userId);
    }

    @Override
    public int insertScore(Score score) throws Exception {
        return scoreDao.insertScore(score);
    }
}
