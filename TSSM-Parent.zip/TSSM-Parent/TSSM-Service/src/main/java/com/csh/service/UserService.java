package com.csh.service;

import com.csh.pojo.User;

import java.util.List;

/**
 * @author Adminstrator
 * @version 1.0
 * @date 2020/6/1
 * @descript 用户业务
 * @package com.bill.service
 */
public interface UserService {

    /**
     * @return java.util.List<com.bill.pojo.Users>
     * @throws Exception
     * @params []
     * @author Adminstrator
     * @createTime 2020/6/1 15:42
     * @description 查询所有的用户
     */
    List<User> findAllUser() throws Exception;

    /**
     * @return com.bill.pojo.Users
     * @throws Exception
     * @params [id]
     * @author Adminstrator
     * @createTime 2020/6/1 15:02
     * @description 根据id查询用户
     */
    User findUserByUserId(Integer userId) throws Exception;

    /**
     * @return com.bill.pojo.Users
     * @throws Exception
     * @params [userName, password]
     * @author Adminstrator
     * @createTime 2020/6/1 15:03
     * @description 根据用户名和密码查找用户
     */
    User findUserByUserNameAndUserPassword(String userName, String password) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [users]
     * @author Adminstrator
     * @createTime 2020/6/1 15:04
     * @description 添加用户
     */
    int insertUser(User user) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [users]
     * @author Adminstrator
     * @createTime 2020/6/1 15:04
     * @description 根据用户id修改用户
     */
    int updateUserByUser(User user) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [id]
     * @author Adminstrator
     * @createTime 2020/6/1 15:35
     * @description 删除一个用户
     */
    int deleteUserByUserId(Integer userId) throws Exception;

    /**
     * @return java.util.List<com.csh.pojo.User>
     * @throws Exception
     * @params [roleId]
     * @author Administrator
     * @createTime 2020/6/2 14:30
     * @description 根据角色查询用户
     */
    List<User> findUserByUserRoleId(Integer roleId) throws Exception;
}
