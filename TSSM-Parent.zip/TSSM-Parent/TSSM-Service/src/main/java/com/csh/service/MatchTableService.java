package com.csh.service;

import com.csh.pojo.MatchTable;

import java.util.List;

/**
 * @author Administrator
 * @version 1.0
 * @date 2020/6/2
 * @descript MatchTable业务实现
 * @package com.csh.service
 */
public interface MatchTableService {

    /**
     * @return java.util.List<com.csh.pojo.MatchTable>
     * @throws
     * @params []
     * @author Administrator
     * @createTime 2020/6/2 12:11
     * @description 查询所有的比赛信息
     */
    List<MatchTable> findAllMatch() throws Exception;

    /**
     * @return java.util.List<com.csh.pojo.MatchTable>
     * @throws
     * @params [matchFlag]
     * @author Administrator
     * @createTime 2020/6/2 12:15
     * @description 参加比赛的球员
     */
    List<MatchTable> findMatchByMatchFlag(String matchFlag) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [matchTable]
     * @author Administrator
     * @createTime 2020/6/2 9:53
     * @description 保存一场赛事
     */
    int insertMatchTable(MatchTable matchTable) throws Exception;

    /**
     * @return com.csh.pojo.MatchTable
     * @throws
     * @params [userId, gameNo]
     * @author Administrator
     * @createTime 2020/6/2 11:10
     * @description 查询是否参加过比赛
     */
    MatchTable findMatchByUserIdAndMatchNo(Integer userId, String gameNo) throws Exception;

    /**
     * @return int
     * @throws Exception
     * @params [matchFlag, matchNo, matchUserId]
     * @author Administrator
     * @createTime 2020/6/2 12:38
     * @description 更新用户参赛状态
     */
    Integer updateMatchByMatchNoAndMatchUserId(String matchFlag, String matchNo, Integer matchUserId) throws Exception;

    /**
     * @return int
     * @throws
     * @params [matchFlag, matchNo, matchUserId]
     * @author Administrator
     * @createTime 2020/6/4 17:47
     * @description 分配裁判
     */
    Integer updateMatchRefereeByMatchNo(Integer matchRefereeId, String matchRefereeName, String matchNo) throws Exception;

    /**
     * @return com.csh.pojo.MatchTable
     * @throws Exception
     * @params [userId, gameNo]
     * @author Administrator
     * @createTime 2020/6/2 11:13
     * @description 某个球员已经参加的比赛
     */
    List<MatchTable> findMatchByUserIdAndMatchFlag(Integer userId, String matchFlag) throws Exception;

    /**
     * @return java.lang.Integer
     * @throws
     * @params [matchFlag, matchNo]
     * @author Administrator
     * @createTime 2020/6/5 18:02
     * @description 根据matchNo更新matchFlag
     */
    Integer updateMatchFlagByMatchNo(String matchFlag, String matchNo) throws Exception;
}
