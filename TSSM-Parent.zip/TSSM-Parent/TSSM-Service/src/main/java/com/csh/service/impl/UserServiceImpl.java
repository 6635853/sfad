package com.csh.service.impl;

import com.csh.dao.UserDao;
import com.csh.pojo.User;
import com.csh.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author Adminstrator
 * @version 1.0
 * @date 2020/6/1
 * @descript 用户业务实现类
 * @package com.bill.service.impl
 */
@Service
@Transactional(rollbackFor = {Exception.class})
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;


    @Override
    public List<User> findAllUser() throws Exception {
        return userDao.findAllUser();
    }

    @Override
    public User findUserByUserId(Integer userId) throws Exception {
        return userDao.findUserByUserId(userId);
    }

    @Override
    public User findUserByUserNameAndUserPassword(String userName, String password) throws Exception {
        return userDao.findUserByUserNameAndUserPassword(userName, password);
    }

    @Override
    public int insertUser(User user) throws Exception {
        return userDao.insertUser(user);
    }

    @Override
    public int updateUserByUser(User user) throws Exception {
        return userDao.updateUserByUser(user);
    }

    @Override
    public int deleteUserByUserId(Integer userId) throws Exception {
        return userDao.deleteUserByUserId(userId);
    }

    @Override
    public List<User> findUserByUserRoleId(Integer roleId) throws Exception {
        return userDao.findUserByUserRoleId(roleId);
    }
}
